<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class StafController extends Controller
{
    //
}
