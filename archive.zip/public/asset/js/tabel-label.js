{
  "data": [
    {
      "id": "1",
      "nama": "Selada Super",
      "author": "Hycost Official",
      "status": "On",
      "tanggal": "23 Juni 2020"
    },
    {
      "id": "2",
      "nama": "Pakcoy Super",
      "author": "Bima",
      "status": "Off",
      "tanggal": "22 Juni 2020"
    },
    {
      "id": "3",
      "nama": "Kangkung Seger",
      "author": "Ivan",
      "status": "Off",
      "tanggal": "21 Juni 2020"
    }
  ]
}