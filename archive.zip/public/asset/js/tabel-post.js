{
  "data": [
    {
      "id": "1",
      "judul": "Judul 1",
      "tag": "tutorial, hidropik, sayur, selada",
      "status": "Pending",
      "tanggal": "23 Juni 2020"
    },
    {
      "id": "2",
      "judul": "Judul 2",
      "tag": "tutorial, hidropik, sayur, selada",
      "status": "Terbit",
      "tanggal": "22 Juni 2020"
    },
    {
      "id": "3",
      "judul": "Judul 3",
      "tag": "tutorial, hidropik, sayur, selada",
      "status": "Terbit",
      "tanggal": "21 Juni 2020"
    }
  ]
}