{
  "data": [
    {
      "id": "1",
      "user": "User 1",
      "komentar": "tutorial, hidropik, sayur, selada",
      "post": "Judul 1",
      "tanggal": "23 Juni 2020",
      "status": "pernah"
    },
    {
      "id": "2",
      "user": "User 2",
      "komentar": "tutorial, hidropik, sayur, selada",
      "post": "Judul 2",
      "tanggal": "22 Juni 2020",
      "status": "belum"
    },
    {
      "id": "3",
      "user": "User 3",
      "komentar": "tutorial, hidropik, sayur, selada",
      "post": "Judul 3",
      "tanggal": "21 Juni 2020",
      "status": "belum"
    }
  ]
}