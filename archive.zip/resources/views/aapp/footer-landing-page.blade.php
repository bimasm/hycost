  <footer class="page-footer hy-b-color-2 z-depth-2">
    <div class="container">
      <div class="row">
        <div class="col l12 s12 center">
          <h5 class="white-text">Hycost</h5>
          <p class="grey-text text-lighten-4">Hydroponic Control System</p>
        </div>
        <div class="col s12 l12 s12 center">
          <ul class="hy-med">
            <li>
              <a href="#!" target="_blank">
                <i class="fab fa-facebook"></i>
              </a>
            </li>
            <li>
              <a href="https://www.instagram.com/hy.cost/?hl=id" target="_blank">
                <i class="fab fa-instagram"></i>
              </a>
            </li>
            <li>
              <a href="#!" target="_blank">
                <i class="fab fa-twitter"></i>
              </a>
            </li>
            <li>
              <a href="#!" target="_blank">
                <i class="fab fa-whatsapp"></i>
              </a>
            </li>
            <!--<li>-->
            <!--  <a href="#!" target="_blank">-->
            <!--    <i class="fab fa-line"></i>-->
            <!--  </a>-->
            <!--</li>-->
          </ul>
        </div>
      </div>
    </div>
    <div class="footer-copyright">
      <div class="container center">
        Hycost.com © Copyright 2020.All rights reserved.
      </div>
    </div>
  </footer>