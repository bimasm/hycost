{{-- <div id="dropdown1" class="dropdown-content drop-ha">
	<div class="drop-akun">

		<div class="drop-akun-icon">
			<i class="material-icons center" style="font-size: 50px;">account_circle</i>
		</div>

		<div class="center drop-name">
			<b>teks</b>
		</div>

		<div class="center drop-dat">
			<a href="#!"><p>Edit Profile</p></a>
		</div>

	</div>

	<div class="divider" tabindex="-1"></div>

	<div class="center">
		<a href="/logout" class="border-but rb-text-1 waves-effect waves-teal btn-flat">Logout</a>
	</div>

</div>

<header>
	<div class="navbar">
		<nav class="hy-nav-dashboard" style="box-shadow: none">

			<div class="nav-wrapper container">
				<div class="left">
					<div class="row" style="margin: 0">
						<div class="col s12">
							<a href="#" data-target="sidenav-2" class="left sidenav-trigger hide-on-medium-and-up"><i class="material-icons">menu</i></a>
							<a href="#!" class="brand-logo">Hycost</a>
						</div>
					</div>
				</div>

				<ul class="right hide-on-med-and-down">
					<li>
						<a href="#!" class="dropdown-trigger grey-text text-darken-2" data-target='dropdown1'>
							<i class="material-icons left">account_circle</i>Nama
						</a>
					</li>
				</ul>
			</div>

		</nav>
	</div>
</header> --}}