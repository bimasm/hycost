
@if(request()->routeIs('UserDashboardForum','UserPostSemuaForum','UserPostAddNewPost','UserKomentarSemua','UserSetting'))
<div class="col s12 m12 l12">
	<div class="alert-hy">
		<div class="alert">
			<span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
			<div class="row no-mar">
				<div class="col s12 m12 l2">a</div>
				<div class="col s12 m12 l8">
					<div class="cont-alert-hy">
						Sekarang anda masih menggunakan Akun Reguler, aktifkan Akun Premium untuk mendapatkan layanan Monitoring Kebun Hidroponik anda dengan cepat dan mudah.
					</div>
					<a class="waves-effect waves-light btn" style="background-color: #56b2b2">Pasang Perangkat Sekarang</a>
				</div>
			</div>
		</div>
	</div>
</div>
@endif